## P1 results after full run

The completed run rejects P1 as currently implemented. Only the auxiliary Lemma A is confirmed; H1, H2, H3, and the bound diagnostic all fail.

This is stronger than a solver-only failure: most primary effect estimates miss their thresholds and several have the wrong sign. However, the run does not conclusively falsify the theoretical P1 idea because the implemented entropy operator materially differs from the slack-based simultaneous operator specified in the research design.

| Component | Result | Main evidence |
|---|---|---|
| Lemma A | Confirmed | Identical marginal VaR/ES, but portfolio tail gap `0.006009` |
| H1 calibration | Rejected | Both empirical and Vine gains are negative |
| H2 decision effect | Rejected | Empirical is worse; Vine is inconclusive and violates mean noninferiority |
| H3 mechanism | Rejected | Interaction `Γ = -0.0000267`, threshold `+0.0000477` |
| Bound diagnostic | Rejected | CVaR-error coverage 100%, but regret coverage falls to 89% |

The generated audit report is [report.html](/C:/Users/enikeev/vscode_projects/phd-project/results/p1/full/summary/report.html).

## Execution and integrity

The run is mechanically complete:

- Full mode, seed `20260902`, Python 3.12.5, `skfolio 1.0.3`.
- Both data hashes and the configuration hash match the current files.
- 150 monthly origins, 3,037 realized trading days, nine portfolio paths and two forecasters.
- All expected CSV, JSON, compressed observation, weight, bootstrap and HTML artifacts exist and parse.
- All nine tests pass. The test run emitted 50 covariance-clipping warnings but no failures.
- Saved decision weights sum to one, remain nonnegative and respect the 10% individual-asset limit.
- No complete origin or decision-optimization failures occurred; all 225 recorded failures came from entropy pooling.

Two provenance limitations remain:

- Source files are not committed or hashed in the manifest, so the exact executed implementation is not cryptographically pinned. The manifest only hashes inputs and configuration; see [run_p1.py](/C:/Users/enikeev/vscode_projects/phd-project/scripts/run_p1.py:27).
- Although `test_end` is configured as 2026-08-25, realized observations stop on 2026-07-31 because the final monthly origin is discarded by the `zip(origins[:-1], origins[1:])` construction in [p1_common.py](/C:/Users/enikeev/vscode_projects/phd-project/scripts/p1_common.py:815).

## Scientific results

### Lemma A

The counterexample works exactly as intended:

- Marginal asset VaR and ES gaps: `0`.
- Equal-weight portfolio VaR changes from `0.011661` to `0.016476`.
- Portfolio ES changes from `0.014576` to `0.020585`.
- Maximum portfolio gap: `0.006009`.

This confirms that marginal calibration does not determine portfolio-tail calibration. As the project itself notes, this is a known problem-setting result, not independent novelty.

### H1: portfolio VaR–ES calibration

The selected single-path entropy baseline won validation for both forecasters. Test-period P1 performance was worse on both required components:

| Forecaster | VaR gain | 95% lower bound | Threshold | ES gain | 95% lower bound | Threshold |
|---|---:|---:|---:|---:|---:|---:|
| Empirical | −0.03189 | −0.05816 | +0.00749 | −0.04877 | −0.08375 | +0.00830 |
| Vine | −0.07599 | −0.10705 | +0.01159 | −0.04105 | −0.07758 | +0.00769 |

Here gain means `baseline deficit − P1 deficit`; negative values therefore mean deterioration. The bootstrap probability of even a positive gain was only 1.2–5.2%, depending on component and forecaster.

There is one informative conditional result: on the 30 of 91 Vine test origins where P1 entropy pooling succeeded, P1 improved both calibration components relative to the selected baseline. This cannot support H1 because it is an endogenously selected feasible subset and approximately two thirds of test origins failed.

### H2: economic decision effect

For the primary empirical forecaster:

- P1 CVaR: `0.028501`; baseline CVaR: `0.028195`.
- Risk gain: `−0.000306`, versus required `+0.001455`.
- Mean-return difference: `−0.000142` per day.
- Both risk and return therefore deteriorated.

For Vine:

- P1 CVaR: `0.030618`; baseline CVaR: `0.032394`.
- Point risk gain: `+0.001776`, slightly above the `0.001601` threshold.
- Its 95% lower bound is only `0.001016`, so superiority is not established.
- Mean difference is `−0.0000261`, slightly worse than the permitted `−0.0000216`; its lower bound is much worse.
- Only 34.6% of bootstrap replicates jointly clear the risk and mean thresholds.

Changing transaction costs from 5 to 20 basis points per unit of turnover does not alter these conclusions.

### H3: proposed mechanism

P1 increases oracle regret in all four factor cells. Mean benefit ranges from `−0.0000044` to `−0.0001306`.

- Interaction estimate: `−0.0000267`.
- 95% lower bound: `−0.0000725`.
- Required effect: `+0.0000477`.
- Solver failures: `223/800 = 27.875%`.

Among successful simulations alone, the benefits are even more negative. The zero-benefit fallback for failures therefore attenuates, rather than creates, the negative H3 result.

### Numerical bound

The computed CVaR-error bound covers all 800 confirmatory observations, with median bound/error ratios around 1.14–1.19. The corresponding regret bound is not uniform:

- High dependence/high complexity: 89%.
- High dependence/low complexity: 95.5%.
- Low dependence/high complexity: 91%.
- Low dependence/low complexity: 98%.

The required 95% coverage in every cell is therefore missed. Moreover, [p1_bounds.py](/C:/Users/enikeev/vscode_projects/phd-project/scripts/p1_bounds.py:24) compares raw empirical proportions to 95% without constructing confidence intervals for those proportions, despite naming the output `confidence_intervals.csv`. The criterion is consequently lenient, yet still fails.

## Why the operator failed

The main cause is incompatibility between the design and its implementation.

The research specification calls for simultaneous fixed VaR–ES constraints with explicit slack variables and a slack penalty; see [phd_concepts.md](/C:/Users/enikeev/vscode_projects/phd-project/phd_concepts.md:652). The code instead applies hard equalities in three sequential batches of three paths in [p1_common.py](/C:/Users/enikeev/vscode_projects/phd-project/scripts/p1_common.py:625).

Consequences:

- P1 projection failed at 91/150 empirical origins and 89/150 Vine origins.
- Test-period P1 failures were 65/91 empirical origins and 61/91 Vine origins.
- Even nominally successful nine-path projections do not preserve all earlier views. Median maximum view errors were:

  - Empirical: VaR `0.00310`, CVaR `0.00325`.
  - Vine: VaR `0.00203`, CVaR `0.00266`.

  These are approximately 7–14% of typical predicted risk levels.

- Three “successful” empirical origins report infinite relative entropy.
- No tolerance on the recorded view residuals is included in the acceptance gate.
- When entropy pooling fails, P1 forecasts fall back to raw probabilities while retaining the `p1` label and `solver_failed=true`; see [p1_common.py](/C:/Users/enikeev/vscode_projects/phd-project/scripts/p1_common.py:882).

Path collinearity aggravates the problem. Median realized pairwise correlations rise from 0.854 to 0.873 between successful and failed empirical origins, and from 0.886 to 0.917 for Vine. Failures occur even at early origins where targets are effectively raw forecasts, indicating that numerical instability—not simply overly aggressive calibration—is material.

The reported `insufficient_tail_support_fraction=0` only says the effective scenario count exceeds the crude 20-tail-observation threshold. It does not establish joint feasibility of nine VaR–ES equality systems.

## Additional design defect: turnover

The configured maximum turnover is 0.50, but actual turnover frequently exceeds it:

- Empirical P1: 55% of test origins exceed 0.50; maximum `1.262`.
- Vine P1: 81% exceed 0.50; maximum `1.533`.
- Similar violations occur for raw, marginal and selected portfolios.

The optimizer constrains only assets in the new top-50 universe, while reported turnover also includes liquidation of names leaving the universe. This follows from the current-column previous-weight construction and union-based realized turnover in [p1_common.py](/C:/Users/enikeev/vscode_projects/phd-project/scripts/p1_common.py:742). Consequently, H2 does not actually satisfy its stated common 0.50 turnover constraint.

## Decision

This run should be archived as a negative confirmatory result. Under P1’s own stopping criteria, the current operationalization should be stopped or downgraded:

- H1 and H2 fail on the primary empirical forecaster.
- H3 fails with the opposite interaction sign.
- The regret bound lacks required coverage.
- The operator is systematically infeasible.
- The implementation does not faithfully realize the proposed slack-based operator.

A redesigned simultaneous/slack or validation-frozen shrinkage operator may still be scientifically testable, but it would constitute a new specification. Because the present test period has now been inspected, tuning or selecting that redesign from these results requires a new untouched confirmation period or an independent dataset.