# План реализации концепции P1 на Python

## 1. Цель и обязательный принцип разработки

Реализовать только P1 из [phd_concepts.md](C:/Users/enikeev/vscode_projects/phd-project/phd_concepts.md): контрпример леммы A, эмпирические H1–H2, имитационную H3 и численную проверку границы calibration residual → CVaR-error → excess risk. T1, U5+, S1+ и остальные концепции не реализуются.

> **КРАЙНЕ НЕОБХОДИМО ПИСАТЬ КОД БЕЗ OVERENGINEERING.**

Практические ограничения:

- один общий функциональный модуль, отдельные исполняемые скрипты и один TOML-конфиг;
- никаких собственных фреймворков, базовых классов, DI, registry, Hydra, MLflow, БД, Airflow, Dask/Ray и самописного backtest engine;
- не дублировать уже существующие в `skfolio` оптимизаторы, меры риска, entropy pooling, walk-forward и bootstrap;
- собственный код — только загрузка данных, P1-специфическая калибровка, identification-моменты, гипотезы и сохранение результатов;
- основной dependency — `skfolio==1.0.3`; второй портфельный фреймворк не нужен.

Нативно использовать `MeanRisk`, `RiskMeasure.CVAR`, `EmpiricalPrior`, `EntropyPooling`, `SyntheticData`, `VineCopula`, `WalkForward`, `value_at_risk`, `cvar`, `EqualWeighted`, `InverseVolatility` и `stationary_bootstrap`. `EntropyPooling` уже поддерживает VaR/CVaR views, L1-slack и posterior scenario weights, поэтому собственный KL/CVXPY-оптимизатор не писать. [Документация EntropyPooling](https://skfolio.org/generated/skfolio.prior.EntropyPooling.html), [WalkForward](https://skfolio.org/generated/skfolio.model_selection.WalkForward.html), [CVaR](https://skfolio.org/generated/skfolio.measures.cvar.html).

## 2. Командные интерфейсы и минимальная структура

Создать:

- `scripts/p1_common.py` — единственный общий модуль с простыми функциями загрузки, формирования universe, калибровки, расчёта моментов, bootstrap и сохранения;
- отдельные `scripts/p1_lemma_a.py`, `p1_h1.py`, `p1_h2.py`, `p1_h3.py`, `p1_bounds.py`;
- `scripts/run_p1.py` — только последовательный вызов перечисленных экспериментов и сбор итогового отчёта;
- `configs/p1.toml`, один `requirements.txt` и один `tests/test_p1.py`.

В самом начале каждого экспериментального скрипта разместить модульный docstring с дословной гипотезой/положением, которое проверяется, включая H0/H1 для H1–H3. Логика гипотез не должна быть спрятана в runner.

Все CLI имеют одинаковые аргументы:

```text
--config configs/p1.toml
--run-dir results/p1/full
--mode smoke|full
```

`full` всегда использует top-50; `smoke` сокращает даты, bootstrap и число симуляций, но не меняет определения метрик. Публичного Python API или устанавливаемого пакета не создавать.

README полностью заменить описанием P1, данных, структуры результатов и точными командами:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe scripts\run_p1.py --config configs\p1.toml --run-dir results\p1\full --mode full
```

Также привести отдельные команды для каждой гипотезы и `pytest -q`. `results/` добавить в `.gitignore`.

## 3. Данные, прогноз и портфельная калибровка

### Эмпирический протокол

- Использовать скорректированный `close` из `qlib_daily_ohlcv_amount.csv` и point-in-time membership CSI 300.
- На каждом месячном origin выбирать 50 текущих членов CSI 300 с максимальной медианной `amount` за предыдущие 60 торговых дней.
- Требовать наличие цен минимум для 95% последних 756 дней и актуальную цену на origin; при менее чем 50 допустимых бумагах завершать run с диагностической ошибкой.
- Рассчитывать простые доходности через `skfolio.preprocessing.prices_to_returns`; пропуски внутри истории после отбора трактовать как нулевую доходность при приостановке торгов посредством forward-fill цены.
- Уровень риска: `alpha=0.95`; lookback сценариев — 756 дней; окно калибровки — 504 дня; ребалансировка — месячная.
- Validation: 2016-01-01–2018-12-31. Locked test: 2019-01-01–2026-08-25. Любое переобучение внутри test использует только уже наблюдавшуюся историю.
- Основные издержки: `0.001 * sum(abs(delta_weight))`; robustness — 5 и 20 bps.

### Forecasters и классы портфелей

- Основной forecaster: rolling `EmpiricalPrior(max_history=756)`.
- Обязательная проверка замены forecaster: `SyntheticData(VineCopula(max_depth=2, n_jobs=-1), n_samples=5000)`.
- Optimization path для калибровки: девять предсказуемых портфелей из `MeanRisk(CVAR, efficient_frontier_size=3)` × `max_weight ∈ {0.05, 0.10, 0.20}`, long-only, budget 1, max turnover 0.50.
- Основное решение H2: минимизация CVaR, long-only, budget 1, max weight 0.10, max turnover 0.50.

Для каждого path-портфеля добавить в матрицу сценариев столбец его доходности `PATH_00`…`PATH_08`. Передать расширенную матрицу напрямую в `EntropyPooling`, задавая VaR/CVaR views на эти столбцы. Затем передать тот же estimator в `MeanRisk`, установив `max_weights=0` для `PATH_*`. Проверено, что posterior weights при этом применяются ко всем исходным активам, а синтетические столбцы получают нулевые портфельные веса.

### Правило \(\mathcal K_\alpha\)

Для каждого path и origin на предыдущих 504 честных OOS-наблюдениях:

1. Рассчитать robust scale \(s_{j,t}\) как trailing MAD × 1.4826, обрезанный фиксированным интервалом `[1e-4, 0.20]`.
2. Инструменты: константа и ограниченный `[-3,3]` z-score 20-дневной волатильности equal-weight CSI 300.
3. Через `sklearn.linear_model.QuantileRegressor(quantile=0.95)` оценить поправку к стандартизованному VaR residual.
4. После поправки VaR через обычную `LinearRegression` оценить поправку, обнуляющую ES identification-момент.
5. Сформировать \(q^\circ,e^\circ\), принудительно обеспечить \(e^\circ\ge q^\circ\) и передать их как views в нативный `EntropyPooling(solver="CLARABEL")`.
6. Из posterior weights повторно вычислить фактические VaR/CVaR функциями `skfolio`; именно они используются в H1 и границах, а не целевые views.

Дополнительно сохранять `relative_entropy_`, `effective_number_of_scenarios_` и фактические нарушения views. Origin не исключать молча. При `N_eff*(1-alpha)<20` ставить `insufficient_tail_support`; если это происходит более чем для 5% test-origin, итог H1/H2 объявлять не подтверждённым из-за недостаточной поддержки.

### Baselines

На validation выбрать и затем заморозить сильнейший baseline по минимальному \(\max(C_1,C_2)\), при равенстве — по FZ0 score:

- raw forecast;
- маргинальная VaR–ES-рекалибровка каждого актива с сохранением исходных scenario ranks;
- стандартный entropy pooling только по одному raw-optimal портфелю.

Маргинальный baseline реализовать одной piecewise-linear tail transformation, а не отдельной модельной иерархией. Дополнительно H2 сравнивает P1 с historical-CVaR, equal-weight и inverse-volatility.

## 4. Эксперименты и сохраняемые диссертационные результаты

- `p1_lemma_a.py`: две двумерные системы с одинаковыми маргинальными распределениями и разной зависимостью; показать совпадение asset VaR/ES и расхождение portfolio VaR/ES. Сохранить таблицу и график.
- `p1_h1.py`: рассчитать \(C_{\alpha,1}\), \(C_{\alpha,2}\), общий максимум, coverage, ES residual и вторичный FZ0 score. Односторонние доверительные границы строить paired stationary bootstrap из `skfolio`, 2000 репликаций пакетами по 100. H1 подтверждается только если обе нижние границы превышают \(\delta_{C,1}\) и \(\delta_{C,2}\).
- `p1_h2.py`: использовать H1 forecast panel, рассчитать net daily returns, CVaR, среднюю доходность, turnover и веса. H2 подтверждается только при снижении CVaR сверх \(\delta_R\) и соблюдении mean non-inferiority.
- `p1_h3.py`: 20 активов, Gaussian margins и t-copula DGP с одинаковой корреляцией 0.3; \(d_L:\nu=30\), \(d_H:\nu=4\). Baseline ошибочно предполагает Gaussian copula. Сложность \(c_L\): max weight 0.10, L2=0.01, turnover 0.25; \(c_H\): max weight 0.50, без L2, turnover 1.0. Использовать 50 pilot и 200 независимых confirmatory repetitions, oracle из 100 000 сценариев; проверить \(\Gamma>\delta_M\).
- `p1_bounds.py`: на oracle-сценариях H3 численно вычислить \(\varepsilon_1,\varepsilon_2,\kappa^\dagger\), фактическую sup-CVaR error и excess risk; проверить информативность границ этапов 1–3. Это численная проверка, не замена математическому доказательству.

Validation-пороги заморозить в `thresholds.json`:

- \(\delta_{C,k}=10\%\) от validation-дефицита выбранного baseline;
- \(\delta_R=5\%\) от validation-CVaR baseline;
- \(\kappa_\mu=10\%\) абсолютной validation-доходности baseline;
- \(\delta_M=10\%\) pilot oracle-regret baseline в ячейке \(d_H,c_H\).

Каждый скрипт пишет в собственную подпапку `run-dir`:

- `observations.csv.gz`/`weights.csv.gz` с исходными расчётными рядами;
- `metrics.csv`, `confidence_intervals.csv`, `verdict.json`;
- Plotly-графики `.html`;
- краткий stdout-вердикт без сокрытия отрицательного результата.

`run_p1.py` дополнительно создаёт `manifest.json` с конфигом, seed `20260902`, версиями библиотек и хешами входных файлов, `summary/hypotheses.csv`, диссертационные сводные таблицы и `summary/report.html`, где сразу видны H1/H2/H3, границы, effect sizes, интервалы, поддержка хвоста и solver failures.

## 5. Тестирование и критерии приёмки

В одном `tests/test_p1.py` покрыть:

- корректность знака loss/return и совпадение weighted VaR/CVaR `skfolio` с аналитическими примерами, включая атом в квантиле;
- отсутствие future dates в universe, liquidity ranking, calibration и validation;
- сумму весов, long-only, max weight/turnover и строго нулевые веса `PATH_*`;
- неотрицательность и сумму posterior probabilities, воспроизводимость seed и пересчёт фактических views;
- искусственный пример, где VaR-калибровка не исправляет ES;
- H1 intersection–union, H2 non-inferiority и H3 interaction verdict;
- smoke end-to-end с проверкой существования и схем всех обязательных файлов.

Полный run считается технически принятой реализацией, если:

- все тесты проходят;
- отсутствует test leakage;
- solver failures не превышают 1% origin и нигде не заменяются fallback-портфелем молча;
- полный отчёт строится одной README-командой;
- каждый эксперимент имеет верхний docstring с проверяемой гипотезой;
- отрицательные научные результаты также сохраняются и отображаются;
- в коде нет собственного оптимизационного/backtest-фреймворка и необоснованных архитектурных слоёв.

Допущения: `close` подтверждён как скорректированный; эмпирическая область ограничена динамическим top-50 по ликвидности внутри CSI 300 и не должна описываться как полный universe CSI 300; NGBoost в первую реализацию не входит; доказательство теоретического положения B выполняется отдельно от Python-кода.
