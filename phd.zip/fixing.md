The failures come from a combination of hard VaR/CVaR constraints, strongly dependent PATH portfolios, and limitations of `skfolio 1.0.3`’s multi-CVaR implementation—not simply insufficient scenario count.

## What “overall failure” means

The H1 value combines failures of both P1 and the single-path entropy baseline:

| Forecaster | P1 failures | Single-path failures | Union reported by H1 |
|---|---:|---:|---:|
| Empirical | 91/150 = 60.7% | 18/150 = 12.0% | 96/150 = 64.0% |
| Vine | 89/150 = 59.3% | 27/150 = 18.0% | 92/150 = 61.3% |

Thus, most failures originate from the nine-path P1 projection, but even the single-path case is not fully reliable.

## Likely causes

1. **The calibrated targets are not guaranteed to be jointly attainable.**

The code estimates \(q^\circ\) and \(e^\circ\) separately and only enforces \(e^\circ\ge q^\circ\). This is necessary but insufficient: there may be no single probability vector over the available scenarios that produces all nine requested VaR and CVaR pairs.

Per-path support clipping does not guarantee joint feasibility.

2. **The PATH portfolios are highly dependent.**

Median pairwise correlations are high:

- successful empirical origins: `0.854`;
- failed empirical origins: `0.873`;
- successful Vine origins: `0.886`;
- failed Vine origins: `0.917`.

Failed Vine systems also have a worse median condition number: approximately `140` versus `106`. Therefore, several nearly redundant equality constraints are imposed on the same scenario probabilities.

3. **`skfolio` treats these views as hard equalities.**

In version 1.0.3, the documented L1 slack is applied to internally fixed moment constraints. It is not applied to ordinary VaR equalities or `cvar_equality` constraints. Consequently, a slightly incompatible CVaR system is genuinely infeasible.

4. **Multi-CVaR is solved through a nested eta search.**

For each candidate vector of VaR thresholds, `skfolio` asks `CLARABEL` to solve an equality-constrained probability problem. Some intermediate eta combinations explored by the root/Powell search are infeasible, and the entire estimator then raises `SolverError`.

This explains why even theoretically compatible raw targets can occasionally fail numerically.

5. **The calibration tail is relatively small.**

A 504-day window contains only about

\[
504(1-0.95)\approx25
\]

tail observations. The current minimum of 100 calibration observations initially provides only about five tail observations. Quantile and especially ES corrections can therefore be unstable or extreme.

6. **Sequential entropy batches do not preserve every earlier view exactly.**

The posterior of one triplet becomes the prior for the next, but previous constraints are not carried forward as hard constraints. This avoids some nine-dimensional failures, but later projections can disturb earlier views. That is consistent with the nontrivial residuals observed even after successful fits.

## Best repair direction

The most defensible minimal solution is a support-aware, validation-frozen shrinkage rule:

\[
q_\lambda=q_{\rm raw}+\lambda(q^\circ-q_{\rm raw}),\qquad
e_\lambda=e_{\rm raw}+\lambda(e^\circ-e_{\rm raw}),
\]

with a small preregistered grid such as

\[
\lambda\in\{1,\;0.75,\;0.5,\;0.25,\;0\}.
\]

At every origin, use the largest \(\lambda\) for which native `EntropyPooling` succeeds and the recomputed view residual is below a fixed tolerance.

Advantages:

- continues using native `skfolio`;
- requires no custom KL optimizer;
- turns feasibility into an explicit observable diagnostic;
- avoids silently replacing P1 with raw forecasts;
- quantifies how much calibration the scenario support can absorb.

However, frequent \(\lambda=0\) must count as failure or “no effective calibration,” not as P1 success.

## Stronger but more invasive solution

A minimal maintained fork of `skfolio` could extend its primal `EntropyPooling` problem with explicit L1 slack on user VaR/CVaR equalities:

\[
\min_p D_{\mathrm{KL}}(p\|p_0)+\rho\lVert s\rVert_1.
\]

That would allow one simultaneous nine-view fit and match the intended P1 operator much better. The fork should:

- expose the penalty/tolerance as parameters;
- report every slack value;
- be pinned to a commit;
- include analytical and infeasible-view tests;
- remain a minimal upstream-style patch, not become a separate framework.

## Additional changes worth considering

- Require at least 400–504 calibration observations rather than 100.
- Cap corrections in robust-scale units, with caps selected only on validation.
- Select three genuinely distinct representative paths instead of nine highly correlated ones, if the theoretical portfolio class can be narrowed.
- Add tail-enriched stress scenarios; more ordinary Vine samples alone are unlikely to solve the issue.
- Require a final simultaneous residual audit for all paths, regardless of solver status.
- Do not expect changing `CLARABEL` tolerances or switching to `TNC` alone to solve joint incompatibility.

Before choosing a repair, the cleanest diagnostic is a validation-only feasibility ladder:

1. one raw path;
2. one calibrated path;
3. three raw paths;
4. three calibrated paths;
5. nine raw paths;
6. nine calibrated paths;
7. repeat across the shrinkage grid.

That will identify separately the numerical, support, calibration-magnitude, and path-complexity contributions. Because the locked test has already been inspected, any redesigned operator would need a new independent confirmation period or dataset.