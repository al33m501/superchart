# T1.1: seasoned-universe CVaR-ребалансировка

Текущий эксперимент репозитория — **T1.1**, post-hoc exploratory-проверка правила
ребалансировки по нижней доверительной границе чистого снижения дневного CVaR.
Концепция взята из [phd_concepts.md](phd_concepts.md) и реализована как
самостоятельная замена неудачным P1 и E1.

Исходный T1 завершён и заморожен в `results/t1/exploratory`: 83 из 91 origins
дали `inference_failure`, из них 81 первым check были зарегистрированы как
`Leading prices` у выбранных новых бумаг без истории на левой границе
inference-окна. T1.1 вносит ровно одну содержательную поправку:
PIT history-support screen до ранжирования по ликвидности. Все численные
параметры оптимизации, окон, bootstrap, alpha-spending, издержек и verdict
остаются прежними. Повторно используется тот же development-период, поэтому
T1.1 не является независимой проверкой или confirmation.

Полный T1.1 уже выполнен: screen устранил все selected-history/IPO failures,
но 47 origins заблокировали отсутствующие origin prices у legacy holdings;
`gate` выполнил только 1 ребалансировку из 91. Поэтому итог остаётся
`not_viable_for_preregistration`. Полный разбор T1 и T1.1 находится в
[concept_T1_results.md](concept_T1_results.md).

Для общего target-портфеля \(w_t^*\) оценивается

\[
\widehat\Delta_t =
\widehat{CVaR}_{0.95}(-w_{t-1}^{\top}R)
-\widehat{CVaR}_{0.95}(-(w_t^*)^{\top}R)
-\frac{c\lVert w_t^*-w_{t-1}\rVert_1}{H_t}.
\]

Политика `gate` исполняет target строго при `LCB > 0`, политика `always`
исполняет тот же target каждый месяц. Главный показатель — относительное
снижение CVaR политики:

\[
g_T = \frac{\rho^{always}-\rho^{gate}}{\rho^{always}}.
\]

Поскольку доступная история уже использовалась при выборе концепции, любой
результат имеет `exploratory_only=true` и `confirmed=false`. Положительный вывод
может называться только `viable_for_preregistration`.

## Эмпирический протокол

- PIT-universe: из текущего `CSI 500 \ CSI 300` сначала исключаются бумаги без
  конечного положительного close на первой из 1 030 требуемых ценовых дат или
  ранее, без raw close на selection-anchor либо на origin. Только после этого
  один раз выбирается liquid top-50 по медианному `amount` последних 60
  торговых дней. Значения inference-доходностей в eligibility и ranking не
  используются.
- Если eligible-бумаг меньше 50, origin завершается явной ошибкой: меньший
  universe, post-ranking substitution и silent fallback запрещены. Пропуск
  ровно на левой границе допустим лишь при ранее наблюдавшемся причинном
  PIT-close; внутренние suspension gaps по-прежнему forward-fill.
- Полные месяцы OOS: январь 2019 — июль 2026, 91 origin. Неполный август 2026
  не используется.
- На каждом origin: 504 старых дневных доходности для inference, 21 день
  embargo и 504 последних доходности для selection.
- Target: один long-only `MeanRisk(MINIMIZE_RISK, CVAR)` с cap 10% и
  `EmpiricalPrior(max_history=504)`. Silent fallback отсутствует.
- Основные издержки: 10 bps на полный union-L1 turnover; 5 и 20 bps —
  robustness. Разовая месячная сумма равномерно списывается по дням следующего
  полного месяца.
- Decision LCB: 5000 paired stationary-bootstrap репликаций, средняя длина
  блока 20, `gamma_t = 0.05 / 91`. Веса в bootstrap не переоптимизируются.
- Alpha-budget относится к основной семье 10 bps; проверки 5 и 20 bps
  сохраняются как отдельные exploratory robustness families с собственным
  таким же расписанием alpha-spending.
- Начальное состояние: нативный `EqualWeighted` без стоимости первоначального
  приобретения. Далее обе политики ежедневно дрейфуют по реализованным
  доходностям.

Cap 10% проверяется у каждого исполнимого target в момент решения. Между
решениями фактические веса могут механически пересечь 10% из-за предписанного
дневного drift; скрытой внутримесячной сделки для возврата к cap нет.

CVaR в результатах является **дневным**, а не месячным. Предполагается, что
поле `close` уже скорректировано. Дополнительно предполагается, что наблюдаемая
ценовая история является допустимым PIT-proxy возраста/seasoning бумаги.
Execution uncertainty из E1 в T1.1 MVP не моделируется. Нативные
`skfolio.measures.cvar` и `Portfolio` получают ряд
доходностей и сами возвращают риск потерь, поэтому ручная смена знака в коде не
делается.

## Данные и установка

Нужны три локальных файла:

```text
data/qlib_daily_ohlcv_amount.csv
data/csi500_daily_membership.csv
data/csi300_daily_membership.csv
```

Рыночная панель должна содержать `date,symbol,close,amount`, membership-файлы —
`date,symbol`. Внутренние пропуски `close` считаются приостановкой и
forward-fill. Для разрыва, начавшегося до окна, разрешён ровно последний
наблюдавшийся PIT-close; genuine leading без prior и отсутствующий raw price на
origin в inference не заполняются. Последовательный legacy holding переносит
уже известный mark между соседними OOS-месяцами; такие переносы фиксируются в
audit и manifest.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Зависимости намеренно минимальны: `skfolio==1.0.3` и `pytest`. Оптимизация,
CVaR, `Portfolio`, преобразование цен, WalkForward и stationary bootstrap
используют нативный `skfolio`.

## Запуск

Обе команды запускают один и тот же полный pipeline и создают одинаковую схему
результатов:

```powershell
.\.venv\Scripts\python.exe scripts\t1_pilot.py --config configs\t1_1.toml --run-dir results\t1_1\exploratory --mode full
.\.venv\Scripts\python.exe scripts\run_t1.py --config configs\t1_1.toml --run-dir results\t1_1\exploratory --mode full
.\.venv\Scripts\python.exe -m pytest -q
```

`--mode smoke` сокращает только число origins и bootstrap-репликаций; такой
запуск предназначен для инженерной проверки и программно не может вернуть
`viable_for_preregistration=true`. Параметры полного протокола фиксированы и
проверяются перед `--mode full`.

Pipeline сохраняет:

```text
decisions.csv.gz
weights.csv.gz
daily_returns.csv.gz
decision_bootstrap.csv.gz
policy_bootstrap.csv.gz
metrics.csv
confidence_intervals.csv
data_audit.csv
verdict.json
manifest.json
report.html
```

`manifest.json` фиксирует seed, конфиг, версии, git-состояние, SHA-256 входов и
T1-исходников, расписание origins, фактические крайние даты, alpha-budget,
per-origin seasoning counts и SHA-256 замороженных manifest/verdict исходного T1.
Научное непринятие критериев даёт `viable_for_preregistration=false` и exit code
0. Ошибка данных, воспроизводимости или вычислительного инварианта завершает
процесс ненулевым exit code.

## Критерий результата

`viable_for_preregistration=true` возможен только при одновременном выполнении
всех проверок из `verdict.json`: без data/PIT/leakage, solver и inference
failures; конечные long-only state weights с единичным budget и target cap 10%;
согласованные turnover и costs; достаточный tail support; не менее 10%
`rebalance` и 10% `hold`; односторонняя 95%-LCB для \(g_T\) строго выше 5%.

Это вычислительный exploratory-эксперимент, а не доказательство равномерной
корректности LCB. Теорема и условия для класса \(\mathcal P\) остаются отдельной
математической частью диссертации.

## Архив отрицательных результатов

Исходный [полный результат T1](concept_T1_results.md) сохранён отдельно и не
перезаписывается запуском T1.1. P1 и E1 не входят в T1.1 и не вызываются его
pipeline. Их код оставлен без
изменений как воспроизводимый архив:

- [результаты P1](concept_P1_results.md);
- [результаты E1](concept_E1_results.md);
- [план E1](E1_impl_plan.md).

В T1/T1.1 не перенесены EntropyPooling, Vine-сценарии, множество frontier paths,
censored boosting, execution-status и интервальные границы.
