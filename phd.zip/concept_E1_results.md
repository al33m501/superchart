# E1 results after the full-history pilot

## Outcome

E1 is rejected as currently operationalized. The full-history pilot completed
successfully, but its indispensable `risk_gap` gate failed. All technical and
numerical gates passed.

This is a negative viability result, not a failed program run. The data passed
all integrity checks, the interval bounds were valid and informative, every
origin produced feasible portfolios, and the solver-failure rate was zero. The
problem is that executable CVaR was not materially greater than frictionless
quote CVaR. The central empirical premise required to justify the more complex
E1 forecasting and optimization stages is therefore absent in this sample.

The authoritative outputs are [verdict.json](results/e1/pilot/verdict.json),
[metrics.csv](results/e1/pilot/metrics.csv),
[confidence_intervals.csv](results/e1/pilot/confidence_intervals.csv), and
[data_audit.csv](results/e1/pilot/data_audit.csv). Earlier pilot results based
on same-day execution returns are superseded by this run.

## What E1 proposed

E1 proposed estimating and minimizing executable portfolio tail risk on the
Chinese A-share market. Its motivating mechanism was:

```text
lower price limit or suspension
    -> sale cannot occur at the frictionless decision price
    -> quoted returns understate executable downside risk
    -> a quote-CVaR optimizer overweights hard-to-exit assets
```

The planned contribution combined:

- interval identification of executable returns from daily execution status;
- valid lower and upper bounds for executable portfolio CVaR;
- a linear portfolio budget for execution uncertainty;
- censored probabilistic gradient boosting for conditional return bounds;
- H1 forecasting, H2 economic, and H3 mechanism tests.

The implementation plan intentionally placed a cheap empirical viability pilot
before H1–H3. Those later tests were to run only if the execution-risk gap was
large, stable, identifiable, and computationally feasible.

## Final return definition

For a decision made after the raw close on day `t`, executable return is measured
from that decision price to the first strictly future session in which the
specified sale is genuinely executable. The position is carried across trading
suspensions and full lower-limit days.

- An exact opening execution produces a point return.
- A day that opens at the lower limit but later trades above it produces an
  interval return because daily bars cannot identify queue position or fill time.
- A full lower-limit day and a suspended day do not terminate the return.
- `execution_date` and `outcome_observed_at` record when the outcome became
  available, and histories at an origin exclude later outcomes.
- Corporate-action reference-price changes are bridged using the prior raw close
  and official `raw_prev_close` so that an ex-date does not create a spurious
  return.
- The frictionless comparator uses the same decision price and the next listed
  session's opening price.

Execution and quote histories are aligned before estimation. A decision date is
ignored only when one or more selected securities lack a genuine preceding quote
price. Both matrices drop that date together, and older observations refill the
window to exactly 756 rows. At most one date was ignored at any origin. New or
relisted securities are excluded until they have at least 757 quote prices.

## Data and execution integrity

The execution-status manifest reports:

- 6,228,600 rows and 1,862 symbols;
- coverage from 2010 through 2026-08-25;
- 6,021,311 exact, 6,368 interval, 6,465 censored, and 194,456 suspended
  daily observations;
- public AINumeric data supplemented by Eastmoney and 33 Tencent fallback rows;
- output SHA-256
  `3330333f1f401982a3532d683d354e7670f3c741ce0aee3d4c2bd398e15c2852`.

All 19 execution-data audit checks have zero failures. These include uniqueness,
OHLC consistency, limit consistency, positive adjustment and reference prices,
valid interval ordering, execution prices inside the daily bar, point-in-time
availability, observation labels, and impossible-execution checks.

The pilot used:

- 152 monthly origins from 2014-01-30 through 2026-08-25;
- a rolling history of 756 jointly usable observations;
- 50 liquid point-in-time CSI 300 constituents at each origin;
- CVaR level 95%;
- eight portfolio paths, giving 1,216 origin/path measurements;
- minimum effective tail support of 37.8 observations.

The complete regression suite passed: 29 tests, with only the existing P1
covariance-clipping warnings.

## Pilot gate results

| Gate | Requirement | Observed result | Decision |
|---|---:|---:|---|
| Data integrity | Every audit check passes | 19/19 checks pass | Pass |
| Relative risk gap | 95% lower bound greater than 5% | **-7.8319%** | **Fail** |
| Median interval width | Less than 50% of executable risk | 0.4483% | Pass |
| 90th-percentile width | Less than 100% | 2.9576% | Pass |
| Bound validity | 95% upper violation rate at most 5% | 0.2461%; no observed violations | Pass |
| Tail support | At least 20 | 37.8 | Pass |
| Solver failures | Less than 1% | 0% | Pass |
| Feasibility | At least 99% | 100% | Pass |

The final verdict is `confirmed: false` solely because `risk_gap` is false.

## Main empirical evidence

Across all 1,216 measurements:

- median quote CVaR was `0.015459`;
- median executable CVaR was `0.015026`;
- median relative risk gap was **-0.005324**, or **-0.5324%**;
- the one-sided 95% lower confidence bound was **-0.078319**;
- only 346 measurements had a positive gap;
- the largest measured gap was **0.046945**, still below the required 5%.

Thus the failure is not marginal: no individual origin/path observation reached
the configured effect threshold, and the confidence bound is negative.

The CVaR-optimized paths all have negative median gaps:

| Portfolio path | Median relative gap |
|---|---:|
| 5% cap, budget off | -0.728% |
| 5% cap, budget on | -0.626% |
| 10% cap, budget off | -1.010% |
| 10% cap, budget on | -0.965% |
| 20% cap, budget off | -1.019% |
| 20% cap, budget on | -0.836% |
| Equal weight | +0.240% |
| Inverse volatility | +0.063% |

The small positive medians for the two naive portfolios remain far below 5%,
while their mean gaps are negative. Annual medians range from approximately
-6.26% to +0.33%; no year clears the 5% threshold. The result is therefore not
created by one isolated crisis year.

## Why E1 was rejected

### 1. The necessary risk wedge is absent

E1 requires quoted returns to understate the economically relevant executable
tail by a material amount. In the observed sample, executable CVaR is instead
slightly lower at the median. Without a positive, stable risk wedge, optimizing
an executable-risk upper bound has no demonstrated empirical advantage over the
simpler quote-risk baseline.

### 2. Eventual-sale return is a variable-horizon outcome

When a lower limit or suspension blocks a sale, the final definition carries the
position until the first executable future session. The price can recover before
that session. The eventual sale return therefore includes both the locked loss
and any intervening rebound, whereas the frictionless comparator ends at the next
session's open.

Consequently, delayed execution does not mechanically imply a worse measured
return. The result is economically coherent under the chosen estimand: an
investor cannot sell during the blocked period, but a loss is recorded only at
the later sale. This timing effect directly weakens, and can reverse, the proposed
positive CVaR gap.

### 3. Informative censoring is rare relative to ordinary observations

Exact daily execution observations dominate the source panel. Interval and
censored rows together are only about 0.21% of all status rows. Suspensions are
more common, but many do not create a sufficiently adverse eventual sale return
after the position is carried forward. The interval machinery is valid, but the
identified uncertainty is too small to support the proposed effect size.

### 4. The negative verdict is not explained by technical failure

The bounds are narrow, no bound violation was observed, tail support is adequate,
all origins are feasible, and no solver failure entered the result. Ignoring more
valid executions, relaxing the gate, or lowering the threshold after observing
the results would select the sample or hypothesis toward the desired conclusion.
Those changes would not rescue the current experiment scientifically.

## What this result does and does not establish

The result establishes that the empirical prerequisite for E1 is not present
under the finalized eventual-sale return definition, current universe, sample,
and 5% materiality threshold. Under the pre-specified staged design, E1 must stop
at the pilot.

It does **not** establish that:

- price limits and suspensions have no economic cost;
- executable-risk bounds are mathematically invalid;
- censored boosting cannot work for another target;
- mark-to-market risk while a position is locked is small;
- liquidation shortfall over a fixed horizon is small.

H1, H2, and H3 were not run on the full experiment because their prerequisite
failed. They should therefore be recorded as **not tested**, not separately
rejected. The pilot is also marked `exploratory_only: true`; it is not an untouched
confirmatory result.

## Decision and next research step

The current E1 specification should be archived as a negative pilot and the
guarded full runner should not be bypassed. Running H1–H3 would add computation
without satisfying their identifying motivation.

A scientifically distinct follow-up could replace eventual-sale return with an
estimand that preserves the economic cost during the blocked interval, for
example:

- fixed-horizon mark-to-market loss plus a liquidation constraint;
- maximum drawdown while sale is impossible;
- liquidation shortfall relative to the original decision price;
- time-to-liquidation jointly modeled with sale price;
- a utility or funding-cost penalty for capital trapped in a suspended asset.

Such a change would define a new experiment rather than a repair of E1. Its
estimand, effect threshold, and acceptance gates should be frozen before testing,
and confirmation should use a new future period, an untouched security universe,
or an independent market. More executions must not be excluded merely to obtain
a positive `risk_gap`.

## Reproduction

The completed pilot was run with:

```powershell
.\.venv\Scripts\python.exe scripts\e1_pilot.py `
  --config configs\e1.toml `
  --run-dir results\e1\pilot `
  --mode full
```

It completed with exit code 0 and wrote `confirmed: false`. This distinction is
intentional: a negative scientific verdict is a valid result, while malformed
data, leakage, or computation errors produce a failing run.
